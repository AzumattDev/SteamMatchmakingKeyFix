| `Version` | `Update Notes`                                                                                             |
|-----------|------------------------------------------------------------------------------------------------------------|
| 1.0.1     | - Use a slightly different and better way to prevent the issue. Provided by KG, altered a small bit by me. |
| 1.0.0     | - Initial Release                                                                                          |